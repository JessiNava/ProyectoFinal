# ProyectoCoder
# proyecto muy basico con las funcionalidades requeridas
# Template de una pagina random.
# 3 modelos 
# Formulario para cada clase
# Tuve un tema con la busqueda en la BD, Yo queria que me busque a TODA la base de datos en general y no limitada solo a una clase con el Class.Object.Filter <--- Para que en el "INICIO" que seria la busqueda en la BD le pida un nombre y me traiga sin importar la clase los datos de dicho "Nombre". Pero no supe como hacero y tampoco me respondio un tutor :( [A pesar de saberlo hacer con el metodo que mencione anteriormente Class.object.Filter, no lo considere apropiado para este ejemplo de pagina. Y no lo integre. Si bien se como funciona el concepto basico que se dicto en clase.]
# el usuario para que usted pueda ingresar es : 
# user: coder_test
# pass: tutor123

# superUser creado con otra cuenta y usuario, que lo puede observar en /admin/

# la URL principal es /AppCoder/ Y ahi ahi Con el menu te lleva a todos lados
# con la URL de busqueda estuve experimentando un poco y alfinal no pude llegar al objetivo deseado. Quedara preguntar a algun tutor o si usted me puede dejar algun tip o devolucion se lo agradeceria. :)