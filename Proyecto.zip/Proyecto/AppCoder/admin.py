from django.contrib import admin
from AppCoder.models import *


# Register your models here.
admin.site.register(Ave)
admin.site.register(Gato)
admin.site.register(Perro)
admin.site.register(Avatar)
admin.site.register(Post)
